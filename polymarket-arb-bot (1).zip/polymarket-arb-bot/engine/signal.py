"""
Divergence-detection signal engine. This module only produces signals — it
does not size or execute anything (that's engine/risk.py and the broker).

Two probability models are available, in priority order:

1. Fair value (engine/fair_value.py) — PRIMARY. Directly answers what the
   contract actually resolves on: given the current price relative to the
   market's REFERENCE price, remaining time, and recent volatility, what's
   the probability of finishing above reference? This replaces an earlier
   design that compared recent momentum to the market's CURRENT price
   without ever considering the reference price at all — which could fire
   an "UP" signal on upward momentum even while price sat well below the
   level the contract actually needs to beat. Requires a reference_price
   and enough recent ticks to estimate volatility; when either is missing
   (e.g. right after startup, or for a market whose reference price wasn't
   captured), this falls back to:

2. Momentum heuristic/calibration (unchanged from the original design) —
   compares recent momentum to Polymarket's current price. Cruder, but
   available immediately with no reference-price dependency.
"""
from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass
from typing import Deque, Optional

from config.settings import Settings
from data.binance_feed import PriceUpdate
from data.polymarket_feed import Market, OrderBook
from engine.calibration import CalibrationModel
from engine.fair_value import FairValueInputs, RealizedVolatilityEstimator, fair_value_probability
from storage.db import Database

logger = logging.getLogger(__name__)

CONFIRMATION_WINDOW = 3        # consecutive ticks required to agree on direction (momentum fallback only)
MOMENTUM_LOOKBACK_S = 30.0     # window over which we measure recent price change (momentum fallback only)
VOLATILITY_LOOKBACK_S = 120.0  # wider window for a more stable realized-vol estimate (fair value model)
MIN_TICKS_FOR_VOLATILITY = 8


@dataclass(frozen=True, slots=True)
class Signal:
    market: Market
    side: str              # "YES" or "NO" — the side implied to be underpriced
    implied_prob: float
    polymarket_prob: float
    edge_pct: float
    confidence: float
    fired: bool
    reason: str
    model_used: str = ""   # "fair_value" or "momentum_fallback", for auditability


class SymbolMomentumTracker:
    """
    Rolling window of recent Binance ticks for one symbol (e.g. BTCUSDT).
    Serves both probability models: direction/momentum for the fallback
    heuristic, and the raw (price, timestamp) series for realized-volatility
    estimation feeding the fair value model.
    """

    def __init__(self, lookback_s: float = MOMENTUM_LOOKBACK_S, maxlen: int = 400):
        self.lookback_s = lookback_s
        self._ticks: Deque[PriceUpdate] = deque(maxlen=maxlen)

    def add(self, update: PriceUpdate) -> None:
        self._ticks.append(update)

    @property
    def latest(self) -> Optional[PriceUpdate]:
        return self._ticks[-1] if self._ticks else None

    def _ticks_in_window(self, lookback_s: Optional[float] = None) -> list[PriceUpdate]:
        if not self._ticks:
            return []
        window = lookback_s if lookback_s is not None else self.lookback_s
        cutoff = self._ticks[-1].received_at - window
        return [t for t in self._ticks if t.received_at >= cutoff]

    def momentum_pct(self) -> Optional[float]:
        """Percent price change over the lookback window. None if insufficient data."""
        window = self._ticks_in_window()
        if len(window) < 2:
            return None
        start, end = window[0].price, window[-1].price
        if start == 0:
            return None
        return (end - start) / start

    def direction_confirmed(self, n: int = CONFIRMATION_WINDOW) -> Optional[str]:
        """
        Returns "UP", "DOWN", or None. Requires the last `n` consecutive ticks
        to agree on direction — guards against firing on a single noisy tick.
        """
        if len(self._ticks) < n:
            return None
        recent = list(self._ticks)[-n:]
        diffs = [b.price - a.price for a, b in zip(recent, recent[1:])]
        if all(d > 0 for d in diffs):
            return "UP"
        if all(d < 0 for d in diffs):
            return "DOWN"
        return None

    def tick_age_s(self) -> Optional[float]:
        return self.latest.age_seconds if self.latest else None

    def prices_and_timestamps(self, lookback_s: float) -> tuple[list[float], list[float]]:
        window = self._ticks_in_window(lookback_s)
        return [t.price for t in window], [t.received_at for t in window]


def _implied_prob_from_momentum(momentum_pct: float, direction: str, sensitivity: float = 8.0) -> float:
    """
    Rough mapping from recent momentum magnitude to an implied probability
    that the asset is higher (YES) at contract expiry. Intentionally simple
    and monotonic — this is the FALLBACK model, used only when the fair
    value model's inputs (reference price, volatility estimate) aren't yet
    available. Note this deliberately does NOT account for the contract's
    reference price, which is exactly the limitation the fair value model
    exists to fix; don't rely on this path once fair value is available.
    """
    magnitude = min(abs(momentum_pct) * sensitivity, 0.49)
    base = 0.5 + magnitude if direction == "UP" else 0.5 - magnitude
    return max(0.01, min(0.99, base))


def _confidence_score(
    tick_age_s: Optional[float],
    book_depth_usd: float,
    direction_confirmed: bool,
    min_liquidity_usd: float,
) -> float:
    """
    Confidence in [0, 1], built from three independent factors:
      - data freshness (Binance tick age)
      - order book depth on the ACTUAL target side (see evaluate() — this now
        always receives the correct side's book, not always the YES book)
      - directional consistency
    """
    if tick_age_s is None:
        freshness_score = 0.0
    else:
        # Full marks under 1s old, linearly decaying to 0 by 5s old.
        freshness_score = max(0.0, min(1.0, 1.0 - (tick_age_s - 1.0) / 4.0))

    depth_score = max(0.0, min(1.0, book_depth_usd / (min_liquidity_usd * 2)))
    consistency_score = 1.0 if direction_confirmed else 0.0

    return (freshness_score + depth_score + consistency_score) / 3.0


class SignalEngine:
    def __init__(self, settings: Settings, db: Database, calibration: Optional[dict[int, CalibrationModel]] = None):
        self.settings = settings
        self.db = db
        self._trackers: dict[str, SymbolMomentumTracker] = {}
        self._calibration = calibration or {}
        self._vol_estimator = RealizedVolatilityEstimator(min_ticks=MIN_TICKS_FOR_VOLATILITY)

    def _tracker_for(self, symbol: str) -> SymbolMomentumTracker:
        if symbol not in self._trackers:
            self._trackers[symbol] = SymbolMomentumTracker()
        return self._trackers[symbol]

    def current_price(self, asset: str) -> Optional[float]:
        """Latest known Binance price for an asset (e.g. "BTC") — used by
        main.py's discovery loop to capture a new market's reference price
        at first sighting."""
        tracker = self._trackers.get(f"{asset}USDT")
        return tracker.latest.price if tracker and tracker.latest else None

    def _momentum_implied_probability(self, momentum: float, direction: str, duration_minutes: int) -> float:
        model = self._calibration.get(duration_minutes)
        if model is not None:
            return model.implied_probability(momentum, direction)
        return _implied_prob_from_momentum(momentum, direction)

    def ingest_price_update(self, update: PriceUpdate) -> None:
        self._tracker_for(update.symbol).add(update)

    async def evaluate(
        self, market: Market, yes_book: OrderBook, no_book: OrderBook, log: bool = True,
    ) -> Signal:
        """
        Compare a model-implied probability of YES against Polymarket's live
        order-book-derived probability, and decide whether to fire a signal.

        Takes BOTH the YES and NO token books — the earlier version only ever
        fetched the YES book, which meant confidence/depth scoring for a
        NO-side signal used the wrong book as an approximation. Every
        evaluation is logged to SQLite by default (log=False lets callers
        recompute a fresh reading for exit-check purposes without polluting
        the audit trail with extra rows).
        """
        symbol = f"{market.asset}USDT"
        tracker = self._tracker_for(symbol)
        tick_age = tracker.tick_age_s()
        current_price = tracker.latest.price if tracker.latest else None

        polymarket_prob = yes_book.mid

        implied_prob: Optional[float] = None
        model_used = ""
        direction_ok = False  # used only for the confidence score's consistency factor

        # -- Primary: fair value model, if we have what it needs --
        if market.reference_price is not None and current_price is not None:
            time_remaining_s = market.time_remaining_s
            if time_remaining_s is not None and time_remaining_s > 0:
                prices, timestamps = tracker.prices_and_timestamps(VOLATILITY_LOOKBACK_S)
                sigma = self._vol_estimator.estimate(prices, timestamps)
                if sigma is not None and sigma > 0:
                    implied_prob = fair_value_probability(FairValueInputs(
                        current_price=current_price,
                        reference_price=market.reference_price,
                        time_remaining_s=time_remaining_s,
                        volatility_per_sqrt_s=sigma,
                    ))
                    model_used = "fair_value"
                    direction_ok = True  # the z-score itself already accounts for noise; no separate gate needed

        # -- Fallback: momentum heuristic/calibration --
        if implied_prob is None:
            direction = tracker.direction_confirmed()
            momentum = tracker.momentum_pct()
            if direction is not None and momentum is not None:
                implied_prob = self._momentum_implied_probability(momentum, direction, market.duration_minutes)
                model_used = "momentum_fallback"
                direction_ok = True

        if implied_prob is None or polymarket_prob is None:
            reason = "insufficient data (no fair-value inputs and no confirmed momentum yet)"
            sig = Signal(
                market=market, side="", implied_prob=0.0, polymarket_prob=polymarket_prob or 0.0,
                edge_pct=0.0, confidence=0.0, fired=False, reason=reason, model_used=model_used,
            )
            if log:
                await self._log(sig, tick_age)
            return sig

        edge_pct = abs(implied_prob - polymarket_prob)
        target_side = "YES" if implied_prob > polymarket_prob else "NO"
        target_book = yes_book if target_side == "YES" else no_book
        # We always BUY the target side's token, so depth on that token's own
        # ask side is what matters — not a proxy inferred from the other book.
        depth_usd = target_book.depth_usd("ask")

        confidence = _confidence_score(
            tick_age_s=tick_age,
            book_depth_usd=depth_usd,
            direction_confirmed=direction_ok,
            min_liquidity_usd=self.settings.MIN_MARKET_LIQUIDITY_USD,
        )

        fired = edge_pct > self.settings.EDGE_THRESHOLD_PCT and confidence > self.settings.MIN_CONFIDENCE
        reason = "OK" if fired else (
            f"edge {edge_pct:.3f} <= threshold {self.settings.EDGE_THRESHOLD_PCT:.3f}"
            if edge_pct <= self.settings.EDGE_THRESHOLD_PCT
            else f"confidence {confidence:.3f} <= min {self.settings.MIN_CONFIDENCE:.3f}"
        )

        sig = Signal(
            market=market, side=target_side, implied_prob=implied_prob,
            polymarket_prob=polymarket_prob, edge_pct=edge_pct, confidence=confidence,
            fired=fired, reason=reason, model_used=model_used,
        )
        if log:
            await self._log(sig, tick_age, depth_usd)
        return sig

    async def _log(self, sig: Signal, tick_age: Optional[float], depth_usd: Optional[float] = None) -> None:
        await self.db.log_signal(
            market_id=sig.market.market_id,
            asset=sig.market.asset,
            implied_prob=sig.implied_prob,
            polymarket_prob=sig.polymarket_prob,
            edge_pct=sig.edge_pct,
            confidence=sig.confidence,
            fired=sig.fired,
            reason=f"[{sig.model_used}] {sig.reason}" if sig.model_used else sig.reason,
            binance_tick_age_s=tick_age,
            book_depth_usd=depth_usd,
        )
