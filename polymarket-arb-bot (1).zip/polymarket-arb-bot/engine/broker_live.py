"""
Live broker implementation, built against py-clob-client-v2 (CLOB V2 — the only
version that works against production as of the 2026-04-28 cutover; see
https://docs.polymarket.com/v2-migration). Every method/enum used here was
verified against the installed package (`python3 -c "import py_clob_client_v2"`),
not guessed from memory — that distinction matters given how much changed in
this migration.

DO NOT WEAKEN THE GATE below. build_live_broker() is still the only way to get
an instance of this class, and it still requires all three
LIVE_TRADING_CONFIRMED_* flags plus PAPER_MODE=False, simultaneously.

Known, deliberate incompleteness (see settle_position docstring): this class
can place orders and read balances/positions, but does NOT implement on-chain
redemption of resolved conditional tokens. Polymarket's V2 collateral is pUSD,
and turning a resolved YES/NO token back into spendable pUSD is a separate
on-chain contract call this project has not verified against the current CTF
contract ABI. Guessing at that call is exactly the kind of thing that costs
someone real money if it's wrong, so it's left as an explicit TODO rather than
fabricated.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

import httpx
from py_clob_client_v2 import (
    AssetType,
    BalanceAllowanceParams,
    ClobClient,
    MarketOrderArgs,
    OrderType,
    PartialCreateOrderOptions,
    Side,
)

from alerts.telegram import AlertLevel, TelegramAlerter
from config.settings import Settings
from data.polymarket_feed import Market

logger = logging.getLogger(__name__)

DATA_API_BASE = "https://data-api.polymarket.com"  # positions/trades, no auth needed for reads
POLYGON_CHAIN_ID = 137


class LiveTradingNotEnabledError(RuntimeError):
    """Raised when build_live_broker() is called without all gate conditions satisfied."""


@dataclass(frozen=True, slots=True)
class LiveFill:
    order_id: str
    market_id: str
    side: str            # "YES" / "NO"
    avg_price: float
    size_usd: float
    shares: float
    fee_usd: float
    raw_response: dict


class LiveBroker:
    """
    Same conceptual interface as PaperBroker (place_order, get_balance,
    settle_position), backed by real CLOB V2 order placement.
    """

    def __init__(self, private_key: str, alerter: TelegramAlerter, signature_type: int = 1):
        # private_key is held only in memory, never logged, never in __repr__.
        self._private_key = private_key
        self.alerter = alerter
        self._client = ClobClient(
            host="https://clob.polymarket.com",
            chain_id=POLYGON_CHAIN_ID,
            key=private_key,
            signature_type=signature_type,
        )
        creds = self._client.create_or_derive_api_key()
        self._client.set_api_creds(creds)
        self._data_client = httpx.AsyncClient(base_url=DATA_API_BASE, timeout=10.0)

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return "LiveBroker(...redacted...)"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.__repr__()

    @property
    def mode(self) -> str:
        return "LIVE"

    async def get_balance(self) -> float:
        """Returns pUSD collateral balance (CLOB V2's settlement asset, 1:1 with USDC)."""
        result = self._client.get_balance_allowance(
            BalanceAllowanceParams(asset_type=AssetType.COLLATERAL)
        )
        # balance is returned in base units (micro-pUSD); divide by 1e6 for a dollar figure.
        return int(result["balance"]) / 1_000_000

    async def place_order(self, market: Market, side: str, size_usd: float) -> LiveFill:
        """
        Places a real FOK market order for size_usd worth of the given side.
        This is real money the moment it's called — build_live_broker()'s gate
        is what stands between this method and an accidental call.
        """
        token_id = market.token_id_yes if side == "YES" else market.token_id_no

        order_args = MarketOrderArgs(
            token_id=token_id,
            amount=size_usd,   # USD-denominated for a BUY market order
            side=Side.BUY,
        )
        resp = self._client.create_and_post_market_order(
            order_args=order_args,
            options=PartialCreateOrderOptions(tick_size="0.01"),
            order_type=OrderType.FOK,
        )

        # Response shape not independently verified against a live order in this
        # environment (no network access to clob.polymarket.com from here) — the
        # field names below are best-effort based on documented examples.
        # scripts/live_smoke_test.py's first real run should confirm/correct these.
        avg_price = float(resp.get("price", 0) or 0)
        shares = float(resp.get("size", 0) or resp.get("makerAmount", 0) or 0)
        fee_usd = float(resp.get("fee", 0) or 0)

        logger.info(
            "[LIVE] Order submitted: %s %s $%.2f -> resp=%s",
            side, market.market_id, size_usd, resp,
        )

        return LiveFill(
            order_id=str(resp.get("orderID", resp.get("orderId", ""))),
            market_id=market.market_id,
            side=side,
            avg_price=avg_price,
            size_usd=size_usd,
            shares=shares,
            fee_usd=fee_usd,
            raw_response=resp,
        )

    async def get_open_positions(self, wallet_address: str) -> list[dict]:
        """
        Read-only: current positions from the public Data API
        (GET https://data-api.polymarket.com/positions?user=<address>).
        No auth required for this read.
        """
        resp = await self._data_client.get("/positions", params={"user": wallet_address})
        resp.raise_for_status()
        return resp.json()

    async def settle_position(self, market: Market):
        """
        NOT IMPLEMENTED — deliberately. Recognizing that a market has resolved
        (via get_open_positions / the Gamma outcome field) is straightforward
        and already done elsewhere in this project. Actually converting a
        resolved conditional token back into spendable pUSD requires an
        on-chain `redeemPositions`-style call against the current CTF/Exchange
        contracts, whose exact V2 ABI this project has not verified. Until
        that's confirmed against Polymarket's own contract docs (not guessed),
        this stays unimplemented rather than risk submitting a malformed
        on-chain transaction with real funds behind it.
        """
        raise NotImplementedError(
            "LiveBroker.settle_position (on-chain redemption of resolved positions) "
            "is intentionally not implemented — verify the current CTF contract "
            "redemption ABI against Polymarket's own docs before building this, "
            "don't guess at a contract call that moves real funds."
        )

    async def aclose(self) -> None:
        await self._data_client.aclose()


def _all_gate_conditions_met(settings: Settings) -> bool:
    return (
        settings.LIVE_TRADING_CONFIRMED_1
        and settings.LIVE_TRADING_CONFIRMED_2
        and settings.LIVE_TRADING_CONFIRMED_3
        and settings.PAPER_MODE is False
    )


async def build_live_broker(settings: Settings, alerter: TelegramAlerter) -> LiveBroker:
    """
    The ONLY way to obtain a LiveBroker instance. Unchanged in spirit from the
    original scaffold:

    1. Reads POLYGON_PRIVATE_KEY strictly from os.environ.
    2. Refuses to instantiate unless ALL THREE LIVE_TRADING_CONFIRMED_* flags
       are True AND PAPER_MODE is explicitly False.
    3. On success, sends a "LIVE TRADING ENABLED" Telegram alert immediately.
    """
    if not _all_gate_conditions_met(settings):
        raise LiveTradingNotEnabledError(
            "Refusing to build a live broker: not all gate conditions are met. "
            "Requires LIVE_TRADING_CONFIRMED_1=True, LIVE_TRADING_CONFIRMED_2=True, "
            "LIVE_TRADING_CONFIRMED_3=True, and PAPER_MODE=False, all simultaneously."
        )

    private_key = os.environ.get("POLYGON_PRIVATE_KEY", "")
    if not private_key:
        raise LiveTradingNotEnabledError(
            "All confirmation flags are set but POLYGON_PRIVATE_KEY is empty in "
            "the environment. Refusing to proceed without it."
        )

    signature_type = int(os.environ.get("POLYMARKET_SIGNATURE_TYPE", "1"))
    broker = LiveBroker(private_key=private_key, alerter=alerter, signature_type=signature_type)

    timestamp = datetime.now(timezone.utc).isoformat()
    await alerter.send_alert(
        f"LIVE TRADING ENABLED at {timestamp}. All three confirmation flags "
        f"were set and PAPER_MODE=False. If this wasn't you, revoke the "
        f"private key immediately.",
        level=AlertLevel.CRITICAL,
    )
    logger.critical("LIVE TRADING ENABLED at %s", timestamp)

    return broker
