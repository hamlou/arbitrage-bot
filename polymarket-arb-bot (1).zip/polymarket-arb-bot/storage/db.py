"""
Async SQLite storage layer, built on aiosqlite. One connection is opened per
call by default (fine at this trade volume); a persistent-connection mode is
available via Database.connect() for the long-running main loop.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Optional

import aiosqlite

logger = logging.getLogger(__name__)

SCHEMA_PATH = Path(__file__).parent / "schema.sql"


class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._conn: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        self._conn = await aiosqlite.connect(self.db_path)
        self._conn.row_factory = aiosqlite.Row
        await self._init_schema(self._conn)

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    async def _init_schema(self, conn: aiosqlite.Connection) -> None:
        # Column migrations must run BEFORE the schema script: schema.sql
        # includes `CREATE INDEX ... ON trades(combo_group_id)`, which fails
        # immediately if `trades` already exists (from an older schema
        # version) without that column yet.
        await self._migrate_missing_columns(conn)
        schema_sql = SCHEMA_PATH.read_text()
        await conn.executescript(schema_sql)
        await conn.commit()

    async def _migrate_missing_columns(self, conn: aiosqlite.Connection) -> None:
        """
        CREATE TABLE IF NOT EXISTS only creates tables that don't exist yet —
        it does NOT retroactively add new columns to a table from an older
        schema version. If you ran this project before the strategy/
        combo_group_id columns were added to `trades`, this adds them so
        existing DB files don't break. Safe to run every startup: checks
        whether `trades` exists at all first (a brand-new DB has nothing to
        migrate — the schema script below creates it correctly from scratch),
        then checks pragma table_info before adding anything.
        """
        cur = await conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='trades'")
        if await cur.fetchone() is None:
            return  # fresh DB — schema script will create it with all columns already

        cur = await conn.execute("PRAGMA table_info(trades)")
        existing_columns = {row[1] for row in await cur.fetchall()}

        migrations = {
            "strategy": "ALTER TABLE trades ADD COLUMN strategy TEXT NOT NULL DEFAULT 'latency_arb'",
            "combo_group_id": "ALTER TABLE trades ADD COLUMN combo_group_id TEXT",
        }
        for column, ddl in migrations.items():
            if column not in existing_columns:
                logger.info("Migrating trades table: adding missing column '%s'", column)
                await conn.execute(ddl)
        await conn.commit()

    def _require_conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database not connected — call `await db.connect()` first")
        return self._conn

    # -- signals -------------------------------------------------------------

    async def log_signal(
        self,
        *,
        market_id: str,
        asset: str,
        implied_prob: float,
        polymarket_prob: float,
        edge_pct: float,
        confidence: float,
        fired: bool,
        reason: str = "",
        binance_tick_age_s: Optional[float] = None,
        book_depth_usd: Optional[float] = None,
    ) -> int:
        conn = self._require_conn()
        cur = await conn.execute(
            """
            INSERT INTO signals
                (ts, market_id, asset, implied_prob, polymarket_prob, edge_pct,
                 confidence, fired, reason, binance_tick_age_s, book_depth_usd)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                time.time(), market_id, asset, implied_prob, polymarket_prob,
                edge_pct, confidence, int(fired), reason, binance_tick_age_s,
                book_depth_usd,
            ),
        )
        await conn.commit()
        return cur.lastrowid

    # -- trades ----------------------------------------------------------

    async def open_trade(
        self,
        *,
        signal_id: Optional[int],
        market_id: str,
        asset: str,
        side: str,
        mode: str,
        entry_price: float,
        size_usd: float,
        fee_usd: float,
        strategy: str = "latency_arb",
        combo_group_id: Optional[str] = None,
    ) -> int:
        conn = self._require_conn()
        cur = await conn.execute(
            """
            INSERT INTO trades
                (signal_id, market_id, asset, side, mode, strategy, combo_group_id,
                 entry_ts, entry_price, size_usd, fee_usd, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN')
            """,
            (signal_id, market_id, asset, side, mode, strategy, combo_group_id,
             time.time(), entry_price, size_usd, fee_usd),
        )
        await conn.commit()
        return cur.lastrowid

    async def close_trade(
        self,
        trade_id: int,
        *,
        exit_price: float,
        exit_reason: str,
        realized_pnl_usd: float,
    ) -> None:
        conn = self._require_conn()
        await conn.execute(
            """
            UPDATE trades
            SET exit_ts = ?, exit_price = ?, exit_reason = ?,
                realized_pnl_usd = ?, status = 'CLOSED'
            WHERE id = ?
            """,
            (time.time(), exit_price, exit_reason, realized_pnl_usd, trade_id),
        )
        await conn.commit()

    async def get_open_trades(self, mode: Optional[str] = None) -> list[dict[str, Any]]:
        conn = self._require_conn()
        if mode:
            cur = await conn.execute(
                "SELECT * FROM trades WHERE status = 'OPEN' AND mode = ?", (mode,)
            )
        else:
            cur = await conn.execute("SELECT * FROM trades WHERE status = 'OPEN'")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_all_trades(self, mode: Optional[str] = None) -> list[dict[str, Any]]:
        conn = self._require_conn()
        if mode:
            cur = await conn.execute("SELECT * FROM trades WHERE mode = ? ORDER BY entry_ts", (mode,))
        else:
            cur = await conn.execute("SELECT * FROM trades ORDER BY entry_ts")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # -- equity curve --------------------------------------------------------

    async def record_equity(self, *, mode: str, balance_usd: float, unrealized_pnl_usd: float = 0.0) -> None:
        conn = self._require_conn()
        await conn.execute(
            "INSERT INTO equity_curve (ts, mode, balance_usd, unrealized_pnl_usd) VALUES (?, ?, ?, ?)",
            (time.time(), mode, balance_usd, unrealized_pnl_usd),
        )
        await conn.commit()

    async def get_equity_curve(self, mode: Optional[str] = None) -> list[dict[str, Any]]:
        conn = self._require_conn()
        if mode:
            cur = await conn.execute("SELECT * FROM equity_curve WHERE mode = ? ORDER BY ts", (mode,))
        else:
            cur = await conn.execute("SELECT * FROM equity_curve ORDER BY ts")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # -- risk events -----------------------------------------------------

    async def log_risk_event(
        self,
        *,
        event_type: str,
        detail: str = "",
        balance_usd: Optional[float] = None,
        drawdown_pct: Optional[float] = None,
    ) -> None:
        conn = self._require_conn()
        await conn.execute(
            """
            INSERT INTO risk_events (ts, event_type, detail, balance_usd, drawdown_pct)
            VALUES (?, ?, ?, ?, ?)
            """,
            (time.time(), event_type, detail, balance_usd, drawdown_pct),
        )
        await conn.commit()

    async def get_risk_events(self) -> list[dict[str, Any]]:
        conn = self._require_conn()
        cur = await conn.execute("SELECT * FROM risk_events ORDER BY ts DESC")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_latest_risk_flag(self, event_type: str) -> Optional[dict[str, Any]]:
        """Most recent row of a given event_type — used to check halt/kill state on startup."""
        conn = self._require_conn()
        cur = await conn.execute(
            "SELECT * FROM risk_events WHERE event_type = ? ORDER BY ts DESC LIMIT 1",
            (event_type,),
        )
        row = await cur.fetchone()
        return dict(row) if row else None

    # -- latency events --------------------------------------------------

    async def log_latency_event(
        self,
        *,
        market_id: str,
        tick_received_at: float,
        signal_evaluated_at: float,
        order_submitted_at: Optional[float],
        fired: bool,
    ) -> None:
        conn = self._require_conn()
        tick_to_signal_ms = (signal_evaluated_at - tick_received_at) * 1000
        signal_to_order_ms = (
            (order_submitted_at - signal_evaluated_at) * 1000 if order_submitted_at else None
        )
        tick_to_order_ms = (
            (order_submitted_at - tick_received_at) * 1000 if order_submitted_at else None
        )
        await conn.execute(
            """
            INSERT INTO latency_events
                (market_id, tick_received_at, signal_evaluated_at, order_submitted_at,
                 tick_to_signal_ms, signal_to_order_ms, tick_to_order_ms, fired)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                market_id, tick_received_at, signal_evaluated_at, order_submitted_at,
                tick_to_signal_ms, signal_to_order_ms, tick_to_order_ms, int(fired),
            ),
        )
        await conn.commit()

    async def get_latency_events(self, fired_only: bool = False) -> list[dict[str, Any]]:
        conn = self._require_conn()
        if fired_only:
            cur = await conn.execute("SELECT * FROM latency_events WHERE fired = 1 ORDER BY id")
        else:
            cur = await conn.execute("SELECT * FROM latency_events ORDER BY id")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]
