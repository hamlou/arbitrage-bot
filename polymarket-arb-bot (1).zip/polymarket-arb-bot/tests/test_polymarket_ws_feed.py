"""
Tests for data/polymarket_ws_feed.py's event-handling logic, using recorded
fixture events. No live WebSocket connection is opened in these tests.
"""
import json
import time
from pathlib import Path

import pytest

from data.polymarket_ws_feed import PolymarketWSFeed

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str):
    return json.loads((FIXTURES / name).read_text())


def test_book_event_populates_cache():
    feed = PolymarketWSFeed(asset_ids=["tok_yes_btc_1"])
    event = load_fixture("sample_ws_book_event.json")

    feed._handle_event(event)

    book = feed.get_cached_book("tok_yes_btc_1")
    assert book is not None
    assert book.best_bid == pytest.approx(0.54)
    assert book.best_ask == pytest.approx(0.56)
    assert feed.is_fresh("tok_yes_btc_1")


def test_unknown_asset_id_price_change_is_ignored_without_base_book():
    feed = PolymarketWSFeed(asset_ids=["tok_yes_btc_1"])
    # No prior 'book' snapshot exists yet for this asset.
    feed._handle_event({
        "event_type": "price_change", "asset_id": "tok_yes_btc_1",
        "price": "0.60", "size": "500", "side": "buy",
    })
    assert feed.get_cached_book("tok_yes_btc_1") is None


def test_price_change_adds_new_bid_level():
    feed = PolymarketWSFeed(asset_ids=["tok_yes_btc_1"])
    feed._handle_event(load_fixture("sample_ws_book_event.json"))

    feed._handle_event({
        "event_type": "price_change", "asset_id": "tok_yes_btc_1",
        "price": "0.545", "size": "100", "side": "buy",
    })

    book = feed.get_cached_book("tok_yes_btc_1")
    prices = [lvl.price for lvl in book.bids]
    assert 0.545 in prices
    # Bids must stay sorted best-first (highest price first).
    assert prices == sorted(prices, reverse=True)


def test_price_change_with_zero_size_removes_level():
    feed = PolymarketWSFeed(asset_ids=["tok_yes_btc_1"])
    feed._handle_event(load_fixture("sample_ws_book_event.json"))
    assert any(lvl.price == pytest.approx(0.54) for lvl in feed.get_cached_book("tok_yes_btc_1").bids)

    feed._handle_event({
        "event_type": "price_change", "asset_id": "tok_yes_btc_1",
        "price": "0.54", "size": "0", "side": "buy",
    })

    book = feed.get_cached_book("tok_yes_btc_1")
    assert not any(lvl.price == pytest.approx(0.54) for lvl in book.bids)


def test_is_fresh_false_when_never_updated():
    feed = PolymarketWSFeed(asset_ids=["tok_yes_btc_1"])
    assert feed.is_fresh("tok_yes_btc_1") is False


def test_is_fresh_false_after_max_age_exceeded():
    feed = PolymarketWSFeed(asset_ids=["tok_yes_btc_1"])
    feed._handle_event(load_fixture("sample_ws_book_event.json"))
    feed._last_update_at["tok_yes_btc_1"] = time.time() - 999
    assert feed.is_fresh("tok_yes_btc_1", max_age_s=5.0) is False


def test_unhandled_event_types_do_not_raise():
    feed = PolymarketWSFeed(asset_ids=["tok_yes_btc_1"])
    for event_type in ("best_bid_ask", "new_market", "market_resolved", "tick_size_change"):
        feed._handle_event({"event_type": event_type, "asset_id": "tok_yes_btc_1"})  # should not raise
