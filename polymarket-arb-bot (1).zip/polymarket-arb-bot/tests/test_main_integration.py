"""
End-to-end integration test for TradingApp, using fake feeds (no live
network). Exercises the full pipeline together: signal evaluation with the
fair-value model, order placement, restart recovery, and the settlement fix
(resolution polled directly by market ID, independent of the active-only
discovery list that caused the original dead-code bug).
"""
import time

import pytest

from config.settings import Settings
from data.binance_feed import PriceUpdate
from data.polymarket_feed import Market, OrderBook, OrderBookLevel
from main import TradingApp
import config.settings as settings_module


class FakePolymarketFeed:
    """Stand-in for PolymarketFeed — no network calls. Books and outcomes are
    controlled directly by the test."""

    def __init__(self):
        self.books: dict[str, OrderBook] = {}
        self.outcomes: dict[str, str] = {}
        self._by_id: dict[str, Market] = {}

    async def discover_active_markets(self) -> list[Market]:
        return [m for m in self._by_id.values() if not m.resolved]

    async def get_order_book(self, market_id: str, token_id: str) -> OrderBook:
        return self.books[token_id]

    async def get_market_outcome(self, market_id: str):
        return self.outcomes.get(market_id)

    async def get_market_by_id(self, market_id: str):
        return self._by_id.get(market_id)

    async def aclose(self):
        pass

    def register(self, market: Market, yes_book: OrderBook, no_book: OrderBook):
        self._by_id[market.market_id] = market
        self.books[market.token_id_yes] = yes_book
        self.books[market.token_id_no] = no_book


def make_market(market_id="m1", reference_price=65000, resolved=False) -> Market:
    return Market(
        market_id=market_id, question="Bitcoin Up or Down - 15 min",
        token_id_yes=f"{market_id}_yes", token_id_no=f"{market_id}_no",
        liquidity_usd=100_000, end_date_iso="2026-07-31T14:00:00Z",
        asset="BTC", duration_minutes=15, resolved=resolved,
        reference_price=reference_price, expires_at_ts=time.time() + 300,
    )


def make_book(token_id: str, best_bid: float, best_ask: float, depth=300_000) -> OrderBook:
    size = depth / ((best_bid + best_ask) / 2)
    return OrderBook(
        market_id="m1", token_id=token_id,
        bids=(OrderBookLevel(price=best_bid, size=size),),
        asks=(OrderBookLevel(price=best_ask, size=size),),
    )


@pytest.fixture
def app_settings(tmp_path):
    return Settings(
        _env_file=None,
        DATABASE_PATH=str(tmp_path / "integration.db"),
        MIN_MARKET_LIQUIDITY_USD=1000,
        EDGE_THRESHOLD_PCT=0.03,
        MIN_CONFIDENCE=0.1,
        STARTING_PAPER_BALANCE_USD=1000,
        MAX_TOTAL_EXPOSURE_PCT=0.5,
    )


async def build_app(app_settings) -> TradingApp:
    # Point the module-level settings singleton at our test settings for the
    # duration of this app instance (main.py reads the module-level `settings`).
    for field in type(app_settings).model_fields:
        setattr(settings_module.settings, field, getattr(app_settings, field))
    app = TradingApp()
    app.feed = FakePolymarketFeed()
    await app.setup()
    return app


async def test_full_pipeline_places_a_trade_on_a_clear_edge(app_settings):
    app = await build_app(app_settings)
    try:
        # Feed Binance ticks showing BTC well above its 65000 reference.
        now = time.time()
        for i, price in enumerate([65000, 65200, 65400, 65600, 65800, 66000, 66200, 66400, 66500, 66600]):
            app.signal_engine.ingest_price_update(
                PriceUpdate(symbol="BTCUSDT", price=price, event_time_ms=0, received_at=now + i, kind="trade")
            )

        market = make_market(reference_price=65000)
        # Polymarket still pricing near 50/50 -- hasn't caught up to the move.
        yes_book = make_book(market.token_id_yes, 0.49, 0.51)
        no_book = make_book(market.token_id_no, 0.49, 0.51)
        app.feed.register(market, yes_book, no_book)
        app._known_markets[market.market_id] = market

        cash = await app.broker.get_balance()
        equity = await app.broker.get_equity(app._known_markets)
        await app._evaluate_and_maybe_trade(market, cash, equity, exposure_headroom=500)

        open_trades = await app.db.get_open_trades(mode="PAPER")
        assert len(open_trades) == 1
        assert open_trades[0]["side"] == "YES"  # price is well above reference -> should lean YES
    finally:
        await app.db.close()


async def test_duplicate_position_prevented(app_settings):
    app = await build_app(app_settings)
    try:
        now = time.time()
        for i, price in enumerate([65000, 65200, 65400, 65600, 65800, 66000, 66200, 66400, 66500, 66600]):
            app.signal_engine.ingest_price_update(
                PriceUpdate(symbol="BTCUSDT", price=price, event_time_ms=0, received_at=now + i, kind="trade")
            )
        market = make_market(reference_price=65000)
        yes_book = make_book(market.token_id_yes, 0.49, 0.51)
        no_book = make_book(market.token_id_no, 0.49, 0.51)
        app.feed.register(market, yes_book, no_book)
        app._known_markets[market.market_id] = market

        cash = await app.broker.get_balance()
        equity = await app.broker.get_equity(app._known_markets)
        await app._evaluate_and_maybe_trade(market, cash, equity, exposure_headroom=500)
        await app._evaluate_and_maybe_trade(market, cash, equity, exposure_headroom=500)  # should be a no-op

        open_trades = await app.db.get_open_trades(mode="PAPER")
        assert len(open_trades) == 1  # not 2 -- duplicate prevented
    finally:
        await app.db.close()


async def test_settlement_works_for_a_market_no_longer_in_active_discovery(app_settings):
    """
    This is the core regression test for the settlement dead-code bug: a
    market that has RESOLVED (and would therefore never again be returned by
    discover_active_markets(), since that filters to closed=false) must still
    be settleable via direct market-ID lookup.
    """
    app = await build_app(app_settings)
    try:
        market = make_market(reference_price=65000, resolved=False)
        yes_book = make_book(market.token_id_yes, 0.49, 0.51)
        no_book = make_book(market.token_id_no, 0.49, 0.51)
        app.feed.register(market, yes_book, no_book)

        fill = await app.broker.place_order(market, "YES", 100)
        assert app.broker.has_open_position(market.market_id)

        # Now the market resolves. Crucially: it's removed from what
        # discover_active_markets() would return (simulated by re-registering
        # as resolved=True), exactly like the real Gamma active=true,closed=false
        # filter would exclude it going forward.
        resolved_market = make_market(reference_price=65000, resolved=True)
        app.feed._by_id[market.market_id] = resolved_market
        app.feed.outcomes[market.market_id] = "YES"

        app._open_position_market_ids = {market.market_id}
        # Run one settlement-loop pass manually (avoiding the infinite loop).
        m = await app.feed.get_market_by_id(market.market_id)
        assert m.resolved is True
        pnl = await app.broker.settle_position(m)

        assert pnl is not None
        assert pnl > 0
        assert not app.broker.has_open_position(market.market_id)
    finally:
        await app.db.close()


async def test_restart_recovery_end_to_end(app_settings):
    """A position opened in one TradingApp instance must be settleable by a
    fresh instance pointed at the same database, simulating a real restart."""
    app1 = await build_app(app_settings)
    market = make_market(reference_price=65000)
    yes_book = make_book(market.token_id_yes, 0.49, 0.51)
    no_book = make_book(market.token_id_no, 0.49, 0.51)
    app1.feed.register(market, yes_book, no_book)
    await app1.broker.place_order(market, "YES", 100)
    await app1.db.close()

    app2 = await build_app(app_settings)
    try:
        assert app2.broker.has_open_position(market.market_id)  # restored on setup()

        resolved_market = make_market(reference_price=65000, resolved=True)
        app2.feed.register(resolved_market, yes_book, no_book)
        app2.feed.outcomes[market.market_id] = "YES"

        pnl = await app2.broker.settle_position(resolved_market)
        assert pnl is not None and pnl > 0
    finally:
        await app2.db.close()
