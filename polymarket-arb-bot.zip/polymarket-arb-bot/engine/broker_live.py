"""
Live broker stub. This file DOES NOT place real orders — every method below
raises NotImplementedError. It exists to define the interface and, more
importantly, the gate that governs whether it can even be instantiated.

DO NOT WEAKEN THIS GATE. If you're tempted to bypass build_live_broker() or
add a shortcut around the three-flag check, that impulse is exactly the
failure mode this file exists to prevent. Implementing real order signing and
submission is a deliberate, separate piece of work to do only after
scripts/validate_paper_run.py has genuinely passed.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Optional

from alerts.telegram import AlertLevel, TelegramAlerter
from config.settings import Settings
from data.polymarket_feed import Market

logger = logging.getLogger(__name__)


class LiveTradingNotEnabledError(RuntimeError):
    """Raised when build_live_broker() is called without all gate conditions satisfied."""


class LiveBroker:
    """
    Same interface as PaperBroker (place_order, get_balance, ...), but every
    method that would touch real funds raises NotImplementedError. Actually
    implementing order signing/submission via py-clob-client is intentionally
    left as future, separate work — this class's job today is to define the
    shape of that future work and make sure nothing can accidentally call it.
    """

    def __init__(self, private_key: str, alerter: TelegramAlerter):
        # private_key is held only in memory for the lifetime of this object.
        # It is never logged, never printed, and deliberately excluded from
        # any __repr__/__str__ below.
        self._private_key = private_key
        self.alerter = alerter

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return "LiveBroker(...redacted...)"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.__repr__()

    @property
    def mode(self) -> str:
        return "LIVE"

    async def get_balance(self) -> float:
        raise NotImplementedError(
            "LiveBroker.get_balance is not implemented. Implementing real wallet "
            "balance queries via py-clob-client is separate work from this "
            "scaffold — do this deliberately, not as a side effect of wiring "
            "the rest of the bot together."
        )

    async def place_order(self, market: Market, side: str, size_usd: float):
        raise NotImplementedError(
            "LiveBroker.place_order is not implemented. Real order signing and "
            "submission via py-clob-client must be built and independently "
            "tested (ideally against small $1-5 sizes per the project's own "
            "checklist) before this can be safely enabled."
        )

    async def settle_position(self, market: Market):
        raise NotImplementedError("LiveBroker.settle_position is not implemented.")


def _all_gate_conditions_met(settings: Settings) -> bool:
    return (
        settings.LIVE_TRADING_CONFIRMED_1
        and settings.LIVE_TRADING_CONFIRMED_2
        and settings.LIVE_TRADING_CONFIRMED_3
        and settings.PAPER_MODE is False
    )


async def build_live_broker(settings: Settings, alerter: TelegramAlerter) -> LiveBroker:
    """
    The ONLY way to obtain a LiveBroker instance.

    1. Reads POLYGON_PRIVATE_KEY strictly from os.environ (not from Settings,
       not from a config file) — one fewer place a key could accidentally
       leak via logging of a settings object.
    2. Refuses to instantiate unless ALL THREE LIVE_TRADING_CONFIRMED_* flags
       are True AND PAPER_MODE is explicitly False.
    3. On success, immediately sends a Telegram "LIVE TRADING ENABLED" alert
       with a timestamp, so there's an audit trail the moment this ever fires.
    """
    if not _all_gate_conditions_met(settings):
        raise LiveTradingNotEnabledError(
            "Refusing to build a live broker: not all gate conditions are met. "
            "Requires LIVE_TRADING_CONFIRMED_1=True, LIVE_TRADING_CONFIRMED_2=True, "
            "LIVE_TRADING_CONFIRMED_3=True, and PAPER_MODE=False, all simultaneously. "
            "This is by design — see the project README before changing any of these."
        )

    private_key = os.environ.get("POLYGON_PRIVATE_KEY", "")
    if not private_key:
        raise LiveTradingNotEnabledError(
            "All confirmation flags are set but POLYGON_PRIVATE_KEY is empty in "
            "the environment. Refusing to proceed without it."
        )

    broker = LiveBroker(private_key=private_key, alerter=alerter)

    timestamp = datetime.now(timezone.utc).isoformat()
    await alerter.send_alert(
        f"LIVE TRADING ENABLED at {timestamp}. All three confirmation flags "
        f"were set and PAPER_MODE=False. If this wasn't you, revoke the "
        f"private key immediately.",
        level=AlertLevel.CRITICAL,
    )
    logger.critical("LIVE TRADING ENABLED at %s", timestamp)

    return broker
