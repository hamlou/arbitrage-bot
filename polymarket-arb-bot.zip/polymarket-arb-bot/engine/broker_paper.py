# NOTE: Polymarket has no sandbox/testnet. There is no faucet, no staging
# environment, no way to place a "fake" order against Polymarket's own infra.
# This PaperBroker is the closest equivalent: it simulates fills against the
# REAL live order book pulled from data/polymarket_feed.py, so slippage and
# spread are realistic, but the USDC balance and positions are entirely
# virtual — no wallet, no private key, no on-chain call anywhere in this file.
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Optional

from data.polymarket_feed import Market, OrderBook, PolymarketFeed
from storage.db import Database

logger = logging.getLogger(__name__)

DEFAULT_FEE_PCT = 0.02  # Polymarket's taker fee schedule changes over time — keep this config-driven.


@dataclass(frozen=True, slots=True)
class Fill:
    trade_id: int
    market_id: str
    side: str            # YES / NO
    avg_price: float
    size_usd: float
    shares: float
    fee_usd: float
    slippage_pct: float  # (avg_price - book_mid_at_entry) / book_mid_at_entry


class InsufficientBalanceError(Exception):
    pass


class PaperBroker:
    """
    Virtual USDC balance + position ledger, with fills computed by walking the
    REAL live order book rather than filling at an idealized midpoint price.
    """

    def __init__(
        self,
        db: Database,
        feed: PolymarketFeed,
        starting_balance_usd: float,
        fee_pct: float = DEFAULT_FEE_PCT,
    ):
        self.db = db
        self.feed = feed
        self.fee_pct = fee_pct
        self.balance_usd = starting_balance_usd
        # market_id -> open trade_id, kept in memory for quick lookups; source of truth is the DB.
        self._open_positions: dict[str, int] = {}

    @property
    def mode(self) -> str:
        return "PAPER"

    async def get_balance(self) -> float:
        return self.balance_usd

    def _walk_book_for_fill(self, book: OrderBook, side: str, size_usd: float) -> tuple[float, float]:
        """
        Simulate a FOK/IOC-style market order by walking order-book levels.
        Buying YES consumes the ask side; buying NO consumes the bid side of
        the same book (Polymarket books are per-token, so in practice the
        caller passes the book for whichever token_id corresponds to `side`).

        Returns (avg_fill_price, shares_filled). Raises if there isn't enough
        depth to fill the requested size_usd (mirrors a real IOC order failing
        to fully fill against thin books).
        """
        levels = book.asks  # we always "buy" the token representing our side; book is that token's book
        remaining_usd = size_usd
        shares = 0.0
        cost = 0.0

        for level in levels:
            level_usd = level.price * level.size
            take_usd = min(remaining_usd, level_usd)
            take_shares = take_usd / level.price
            shares += take_shares
            cost += take_usd
            remaining_usd -= take_usd
            if remaining_usd <= 1e-9:
                break

        if remaining_usd > 1e-9:
            raise ValueError(
                f"Insufficient order-book depth to fill ${size_usd:.2f}; "
                f"only ${cost:.2f} fillable at current book"
            )

        avg_price = cost / shares if shares > 0 else 0.0
        return avg_price, shares

    async def place_order(self, market: Market, side: str, size_usd: float) -> Fill:
        """
        side: "YES" or "NO". Walks the real live order book for the
        corresponding token to compute a realistic average fill price,
        exactly as a real FOK/IOC order would experience.
        """
        if size_usd <= 0:
            raise ValueError("size_usd must be positive")
        if size_usd > self.balance_usd:
            raise InsufficientBalanceError(
                f"Requested ${size_usd:.2f} exceeds paper balance ${self.balance_usd:.2f}"
            )

        token_id = market.token_id_yes if side == "YES" else market.token_id_no
        book = await self.feed.get_order_book(market.market_id, token_id)

        mid_before = book.mid
        avg_price, shares = self._walk_book_for_fill(book, side, size_usd)
        fee_usd = size_usd * self.fee_pct

        total_cost = size_usd + fee_usd
        if total_cost > self.balance_usd:
            raise InsufficientBalanceError(
                f"Order cost incl. fees ${total_cost:.2f} exceeds paper balance ${self.balance_usd:.2f}"
            )

        self.balance_usd -= total_cost

        slippage_pct = 0.0
        if mid_before:
            slippage_pct = (avg_price - mid_before) / mid_before

        trade_id = await self.db.open_trade(
            signal_id=None,
            market_id=market.market_id,
            asset=market.asset,
            side=side,
            mode=self.mode,
            entry_price=avg_price,
            size_usd=size_usd,
            fee_usd=fee_usd,
        )
        self._open_positions[market.market_id] = trade_id
        await self.db.record_equity(mode=self.mode, balance_usd=self.balance_usd)

        logger.info(
            "[PAPER] Filled %s %s $%.2f @ avg %.4f (slippage %.2f%%, fee $%.2f)",
            side, market.market_id, size_usd, avg_price, slippage_pct * 100, fee_usd,
        )

        return Fill(
            trade_id=trade_id,
            market_id=market.market_id,
            side=side,
            avg_price=avg_price,
            size_usd=size_usd,
            shares=shares,
            fee_usd=fee_usd,
            slippage_pct=slippage_pct,
        )

    async def settle_position(self, market: Market) -> Optional[float]:
        """
        Settle an open position at contract expiry using the ACTUAL resolved
        outcome pulled from Gamma (not a simulated/assumed outcome). Returns
        realized PnL in USD, or None if there was no open position or the
        market isn't resolved yet.
        """
        trade_id = self._open_positions.get(market.market_id)
        if trade_id is None:
            return None

        outcome = await self.feed.get_market_outcome(market.market_id)
        if outcome is None:
            return None  # not resolved yet, caller should retry later

        open_trades = await self.db.get_open_trades(mode=self.mode)
        trade = next((t for t in open_trades if t["id"] == trade_id), None)
        if trade is None:
            return None

        won = (trade["side"] == "YES" and outcome == "YES") or (trade["side"] == "NO" and outcome == "NO")
        shares = trade["size_usd"] / trade["entry_price"] if trade["entry_price"] else 0.0
        exit_price = 1.0 if won else 0.0
        payout = shares * exit_price
        realized_pnl = payout - trade["size_usd"] - trade["fee_usd"]

        self.balance_usd += payout

        await self.db.close_trade(
            trade_id,
            exit_price=exit_price,
            exit_reason="SETTLED",
            realized_pnl_usd=realized_pnl,
        )
        await self.db.record_equity(mode=self.mode, balance_usd=self.balance_usd)
        del self._open_positions[market.market_id]

        logger.info(
            "[PAPER] Settled %s: %s, PnL $%.2f, balance now $%.2f",
            market.market_id, "WIN" if won else "LOSS", realized_pnl, self.balance_usd,
        )
        return realized_pnl
