-- polymarket-arb-bot storage schema
-- Every evaluated opportunity is logged, not just executed trades, so we can
-- audit false negatives (edges that existed but didn't meet threshold/confidence).

CREATE TABLE IF NOT EXISTS signals (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              REAL    NOT NULL,          -- unix epoch seconds
    market_id       TEXT    NOT NULL,
    asset           TEXT    NOT NULL,          -- BTC / ETH
    implied_prob    REAL    NOT NULL,          -- from Binance-derived momentum
    polymarket_prob REAL    NOT NULL,          -- from live order book mid
    edge_pct        REAL    NOT NULL,
    confidence      REAL    NOT NULL,
    fired           INTEGER NOT NULL,          -- 0/1, did it pass thresholds
    reason          TEXT,                      -- why it fired or didn't
    binance_tick_age_s REAL,
    book_depth_usd  REAL
);
CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts);
CREATE INDEX IF NOT EXISTS idx_signals_market ON signals(market_id);

CREATE TABLE IF NOT EXISTS trades (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_id       INTEGER REFERENCES signals(id),
    market_id       TEXT    NOT NULL,
    asset           TEXT    NOT NULL,
    side            TEXT    NOT NULL,          -- YES / NO
    mode            TEXT    NOT NULL,          -- PAPER / LIVE
    entry_ts        REAL    NOT NULL,
    entry_price     REAL    NOT NULL,
    size_usd        REAL    NOT NULL,
    fee_usd         REAL    NOT NULL DEFAULT 0,
    exit_ts         REAL,
    exit_price      REAL,
    exit_reason     TEXT,                      -- SETTLED / MANUAL_EXIT / ...
    realized_pnl_usd REAL,
    status          TEXT    NOT NULL DEFAULT 'OPEN'  -- OPEN / CLOSED
);
CREATE INDEX IF NOT EXISTS idx_trades_market ON trades(market_id);
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);

CREATE TABLE IF NOT EXISTS equity_curve (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              REAL    NOT NULL,
    mode            TEXT    NOT NULL,          -- PAPER / LIVE
    balance_usd     REAL    NOT NULL,
    unrealized_pnl_usd REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_equity_ts ON equity_curve(ts);

CREATE TABLE IF NOT EXISTS risk_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              REAL    NOT NULL,
    event_type      TEXT    NOT NULL,          -- DAILY_HALT / KILL_SWITCH / MANUAL_RESET
    detail          TEXT,
    balance_usd     REAL,
    drawdown_pct    REAL
);
CREATE INDEX IF NOT EXISTS idx_risk_events_ts ON risk_events(ts);
