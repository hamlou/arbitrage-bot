"""
polymarket-arb-bot entry point.

Run with: python main.py

There is exactly one function in this file that decides paper vs. live —
get_broker() — and it is not something any other code path bypasses.
"""
from __future__ import annotations

import asyncio
import logging
import signal
import sys
from typing import Union

from alerts.telegram import AlertLevel, build_alerter
from config.settings import settings
from data.binance_feed import BinanceFeed
from data.polymarket_feed import PolymarketFeed
from engine.broker_live import LiveBroker, LiveTradingNotEnabledError, build_live_broker
from engine.broker_paper import PaperBroker
from engine.risk import RiskManager, SignalForSizing
from engine.signal import SignalEngine
from storage.db import Database
from ui.dashboard import DashboardState, run_dashboard

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
)
logger = logging.getLogger("main")

POLL_INTERVAL_S = 1.0


async def get_broker(db: Database, feed: PolymarketFeed, alerter) -> Union[PaperBroker, LiveBroker]:
    """
    The single decision point for paper vs. live. Returns PaperBroker unless
    ALL THREE LIVE_TRADING_CONFIRMED_* flags are True AND PAPER_MODE is
    explicitly False — in which case it returns a LiveBroker via the gated
    factory in engine/broker_live.py.

    There is no other code path in this project that trades live.
    """
    try:
        return await build_live_broker(settings, alerter)
    except LiveTradingNotEnabledError:
        logger.info("Live trading gate not satisfied (this is the default and expected state) — using PaperBroker")
        return PaperBroker(
            db=db,
            feed=feed,
            starting_balance_usd=settings.STARTING_PAPER_BALANCE_USD,
        )


class TradingApp:
    def __init__(self):
        self.db = Database(settings.DATABASE_PATH)
        self.alerter = build_alerter(settings.TELEGRAM_BOT_TOKEN, settings.TELEGRAM_CHAT_ID)
        self.feed = PolymarketFeed(min_liquidity_usd=settings.MIN_MARKET_LIQUIDITY_USD)
        self.binance_feed = BinanceFeed()
        self.signal_engine: SignalEngine | None = None
        self.risk: RiskManager | None = None
        self.broker: Union[PaperBroker, LiveBroker, None] = None
        self._shutdown = asyncio.Event()
        self._dashboard_state = DashboardState()

    async def setup(self) -> None:
        await self.db.connect()
        self.signal_engine = SignalEngine(settings, self.db)
        self.risk = RiskManager(settings, self.db, self.alerter)
        self.broker = await get_broker(self.db, self.feed, self.alerter)
        await self.risk.load_state(await self.broker.get_balance())

        mode_label = "PAPER" if isinstance(self.broker, PaperBroker) else "LIVE"
        self._dashboard_state.mode = mode_label
        logger.info("Startup complete. Mode=%s", mode_label)
        await self.alerter.send_alert(f"Bot starting up in {mode_label} mode.", level=AlertLevel.INFO)

    async def _binance_ingest_loop(self) -> None:
        async for update in self.binance_feed.stream():
            self.signal_engine.ingest_price_update(update)
            if self._shutdown.is_set():
                return

    async def _trading_loop(self) -> None:
        while not self._shutdown.is_set():
            try:
                await self._trading_cycle()
            except Exception:
                logger.exception("Unhandled error in trading cycle — continuing after backoff")
                await self.alerter.send_alert(
                    "Unhandled error in trading cycle (see logs). Continuing after backoff.",
                    level=AlertLevel.WARNING,
                )
            await asyncio.sleep(POLL_INTERVAL_S)

    async def _trading_cycle(self) -> None:
        balance = await self.broker.get_balance()
        await self.risk.update(balance)
        self._dashboard_state.balance_usd = balance
        self._dashboard_state.daily_halted = self.risk.daily_halted
        self._dashboard_state.kill_switch_tripped = self.risk.kill_switch_tripped

        if not self.risk.is_trading_allowed():
            return  # halted or kill-switched — evaluate nothing new, just idle

        markets = await self.feed.discover_active_markets()
        for market in markets:
            try:
                token_id = market.token_id_yes
                book = await self.feed.get_order_book(market.market_id, token_id)
            except Exception:
                logger.debug("Could not fetch order book for %s, skipping this cycle", market.market_id)
                continue

            signal = await self.signal_engine.evaluate(market, book)
            if not signal.fired:
                continue

            size_usd = self.risk.position_size(
                SignalForSizing(edge_pct=signal.edge_pct, entry_price=book.mid or 0.5),
                current_balance=balance,
            )
            if size_usd <= 0:
                continue

            try:
                fill = await self.broker.place_order(market, signal.side, size_usd)
                await self.alerter.send_alert(
                    f"[{self.broker.mode}] Opened {signal.side} {market.asset} "
                    f"${size_usd:.2f} @ {fill.avg_price:.3f} (edge {signal.edge_pct:.2%})",
                    level=AlertLevel.INFO,
                )
            except Exception:
                logger.exception("Order placement failed for market %s", market.market_id)

        # Attempt to settle any positions whose markets have since resolved.
        for market in markets:
            if market.resolved:
                try:
                    await self.broker.settle_position(market)
                except Exception:
                    logger.exception("Settlement failed for market %s", market.market_id)

    def _get_dashboard_state(self) -> DashboardState:
        return self._dashboard_state

    async def run(self) -> None:
        await self.setup()

        loop = asyncio.get_running_loop()
        for sig_name in ("SIGINT", "SIGTERM"):
            if hasattr(signal, sig_name):
                loop.add_signal_handler(getattr(signal, sig_name), self._shutdown.set)

        tasks = [
            asyncio.create_task(self._binance_ingest_loop(), name="binance_ingest"),
            asyncio.create_task(self._trading_loop(), name="trading_loop"),
            asyncio.create_task(run_dashboard(self._get_dashboard_state), name="dashboard"),
        ]

        await self._shutdown.wait()
        logger.info("Shutdown signal received, cancelling tasks...")
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        await self.feed.aclose()
        await self.db.close()
        logger.info("Shutdown complete.")


async def main() -> None:
    app = TradingApp()
    await app.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)
