# polymarket-arb-bot

A latency-arbitrage research bot for Polymarket's short-duration (5/15-minute)
BTC/ETH up-or-down contracts. It watches Binance for price moves, compares
that to Polymarket's live order-book-implied probability, and — if a big
enough, high-confidence gap appears — takes the side of the trade that gap
implies.

## Paper-first, on purpose

**Polymarket has no official testnet.** There's no faucet, no sandbox, no way
to send Polymarket itself a "fake" order. So instead of pretending otherwise,
this project builds its own paper-trading simulator (`engine/broker_paper.py`)
that fills orders against the **real, live order book** pulled from
`data/polymarket_feed.py`. Your balance and positions are entirely virtual —
nothing here ever touches a wallet — but the slippage, spread, and fill prices
you see are what a real order would have actually gotten.

That's this project's real "testnet." Treat it as such: **run it for at least
a week and 200+ trades before you even think about live mode.**

## What ships enabled by default

- `PAPER_MODE=True`
- All three `LIVE_TRADING_CONFIRMED_*` flags `False`
- No live order path is reachable from `main.py` unless all three flags are
  `True` **and** `PAPER_MODE` is explicitly `False`, simultaneously
  (`engine/broker_live.py::build_live_broker`)
- A startup assertion that hard-crashes if a real `POLYGON_PRIVATE_KEY` is
  present while `PAPER_MODE=True` — a real key has no business anywhere near
  a "risk-free" run

Live order signing/submission (`LiveBroker.place_order` etc.) is left as
`NotImplementedError`. Building that out is deliberately separate work you do
once — and only once — `scripts/validate_paper_run.py` passes.

## Project layout

```
config/settings.py     pydantic Settings — every threshold lives here, nowhere else
data/binance_feed.py    public Binance WS feed (no API key needed)
data/polymarket_feed.py public Gamma + CLOB read-only client (no credentials needed)
engine/signal.py        edge/confidence computation; logs every evaluation, fired or not
engine/risk.py          Kelly sizing + hard cap, daily halt, persistent kill switch
engine/broker_paper.py  the actual "testnet" — fills against real live book depth
engine/broker_live.py   gated stub; NotImplementedError until you build it deliberately
storage/                SQLite schema + async read/write helpers
alerts/telegram.py      Telegram notifications; never crashes the loop if it fails
ui/dashboard.py         rich terminal dashboard, refreshes independently of the trading loop
scripts/validate_paper_run.py   PASS/FAIL gate — run this before touching Prompt 6
scripts/export_csv.py           dump trades/equity to CSV
tests/                  unit tests using recorded fixtures — no live network calls
```

## Setup

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # defaults are already paper-safe; edit Telegram fields if you want alerts
python main.py
```

A note on network access: `data/binance_feed.py` and `data/polymarket_feed.py`
need outbound access to `stream.binance.com`, `gamma-api.polymarket.com`, and
`clob.polymarket.com`. If you're running this somewhere with restricted
egress, make sure those are reachable — the bot can't do anything useful
without live market data.

## Running the tests

```bash
pytest -q
```

All tests use recorded fixture data (`tests/fixtures/`) — none of them hit a
live endpoint, per the original design brief. 36 tests, currently all passing.

## The actual gate before you go live

Run this after a week+ of paper trading:

```bash
python scripts/validate_paper_run.py
```

It checks, against your real paper-trade history:
- ≥ 200 completed trades
- ≥ 7 calendar days elapsed
- ≥ 70% win rate
- **positive expectancy per trade after modeled fees and slippage** (not before)
- max observed drawdown < your configured kill-switch threshold

If it fails, that's the answer: keep paper trading. Don't lower the thresholds
in `config/settings.py` until the number you want appears — that's optimizing
the test, not the strategy.

## Before you ever flip `PAPER_MODE` to `False`

This isn't code, it's a checklist — go through it honestly:

- Does your expectancy stay positive if the arbitrage window is meaningfully
  shorter by the time you're live than it was during your paper run? (This
  window has been shrinking industry-wide; don't model for today's number.)
- Have you priced in Polygon gas and Polymarket's fee schedule on the
  short-duration markets specifically?
- Is your Polygon RPC endpoint fast enough to compete, or is a free/shared one
  adding latency your paper run never accounted for?
- Can you actually afford to lose the entire amount you're about to deposit,
  with zero effect on anything else in your life? If the honest answer is no,
  that's a signal to stay in paper mode longer — not a signal to lower the
  thresholds until the numbers say what you want them to say.

None of this is financial advice — it's an engineering risk checklist, same
as the one that shipped with the original prompt set this project was built
from.
