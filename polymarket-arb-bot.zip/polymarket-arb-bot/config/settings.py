"""
Central configuration for polymarket-arb-bot.

Design intent: this file is the single source of truth for every threshold and
flag that affects risk. Nothing outside this module should hardcode a magic
number for position sizing, drawdown limits, or the live-trading gate.
"""
from __future__ import annotations

from typing import Optional

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Mode -----------------------------------------------------------
    PAPER_MODE: bool = True

    # --- Live trading gate (see engine/broker_live.py) -------------------
    # Three independent flags. All three, plus PAPER_MODE=False, are required
    # before build_live_broker() will ever instantiate a real broker.
    LIVE_TRADING_CONFIRMED_1: bool = False
    LIVE_TRADING_CONFIRMED_2: bool = False
    LIVE_TRADING_CONFIRMED_3: bool = False

    # --- Risk parameters --------------------------------------------------
    MAX_POSITION_PCT: float = 0.08
    DAILY_LOSS_HALT_PCT: float = 0.20
    TOTAL_DRAWDOWN_KILL_PCT: float = 0.40

    # --- Signal thresholds --------------------------------------------------
    EDGE_THRESHOLD_PCT: float = 0.05
    MIN_CONFIDENCE: float = 0.85
    MIN_MARKET_LIQUIDITY_USD: float = 50_000.0

    # --- Paper trading ----------------------------------------------------
    STARTING_PAPER_BALANCE_USD: float = 1000.0

    # --- Telegram -----------------------------------------------------------
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_CHAT_ID: Optional[str] = None

    # --- Live credentials ---------------------------------------------------
    # Deliberately: no default, never logged, never printed, never included in
    # __repr__. Pydantic's default repr would print field values, so we
    # override __repr__ / __str__ below to redact this specific field.
    POLYGON_PRIVATE_KEY: Optional[str] = Field(default=None, repr=False)

    # --- Storage --------------------------------------------------------
    DATABASE_PATH: str = "storage/arb_bot.db"

    # --- Validators ----------------------------------------------------------
    @field_validator(
        "MAX_POSITION_PCT",
        "DAILY_LOSS_HALT_PCT",
        "TOTAL_DRAWDOWN_KILL_PCT",
        "EDGE_THRESHOLD_PCT",
        "MIN_CONFIDENCE",
    )
    @classmethod
    def _must_be_fraction(cls, v: float, info) -> float:
        if not (0 < v <= 1):
            raise ValueError(f"{info.field_name} must be in (0, 1], got {v}")
        return v

    @model_validator(mode="after")
    def _fail_loudly_if_key_present_in_paper_mode(self) -> "Settings":
        """
        Hard safety rail: a real private key has no business being loaded
        while we believe we're in a zero-risk paper run. This is intentionally
        a hard crash, not a warning — silent misconfiguration here is exactly
        the failure mode that costs people money.
        """
        if self.PAPER_MODE and self.POLYGON_PRIVATE_KEY:
            raise RuntimeError(
                "SAFETY HALT: POLYGON_PRIVATE_KEY is set while PAPER_MODE=True. "
                "This should never happen — paper mode must never have access to "
                "a real wallet key. Remove POLYGON_PRIVATE_KEY from your "
                "environment/.env, or set PAPER_MODE=False only once you have "
                "deliberately decided to go live (see engine/broker_live.py)."
            )
        return self

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return "Settings(...redacted...)"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.__repr__()


# Module-level singleton, imported everywhere else as `from config.settings import settings`
settings = Settings()
