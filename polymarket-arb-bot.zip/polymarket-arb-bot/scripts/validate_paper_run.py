"""
Reads SQLite paper-trade history and reports whether it meets the acceptance
criteria for even considering Prompt 6's live-trading gate. Run this BEFORE
touching any LIVE_TRADING_CONFIRMED_* flag.

Usage:
    python scripts/validate_paper_run.py
    python scripts/validate_paper_run.py --min-trades 300 --min-win-rate 0.75
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import settings  # noqa: E402
from storage.db import Database  # noqa: E402

DEFAULT_MIN_TRADES = 200
DEFAULT_MIN_DAYS = 7
DEFAULT_MIN_WIN_RATE = 0.70


@dataclass
class ValidationResult:
    total_trades: int
    win_rate: float
    expectancy_usd: float
    max_drawdown_pct: float
    days_elapsed: float
    passed: bool
    failures: list[str]


def _compute_max_drawdown_pct(equity_rows: list[dict]) -> float:
    if not equity_rows:
        return 0.0
    peak = equity_rows[0]["balance_usd"]
    max_dd = 0.0
    for row in equity_rows:
        bal = row["balance_usd"]
        peak = max(peak, bal)
        if peak > 0:
            dd = (peak - bal) / peak
            max_dd = max(max_dd, dd)
    return max_dd


async def validate(
    min_trades: int,
    min_days: float,
    min_win_rate: float,
    kill_threshold_pct: float,
) -> ValidationResult:
    db = Database(settings.DATABASE_PATH)
    await db.connect()

    trades = await db.get_all_trades(mode="PAPER")
    equity = await db.get_equity_curve(mode="PAPER")
    await db.close()

    closed = [t for t in trades if t["status"] == "CLOSED" and t["realized_pnl_usd"] is not None]
    total_trades = len(closed)

    wins = [t for t in closed if t["realized_pnl_usd"] > 0]
    win_rate = (len(wins) / total_trades) if total_trades else 0.0

    # Expectancy per trade AFTER modeled fees and slippage: realized_pnl_usd
    # already has fees deducted (see broker_paper.py), and entry_price already
    # reflects simulated slippage from walking the real order book — so a
    # simple mean of realized_pnl_usd is expectancy net of both.
    expectancy_usd = (sum(t["realized_pnl_usd"] for t in closed) / total_trades) if total_trades else 0.0

    max_drawdown_pct = _compute_max_drawdown_pct(equity)

    if closed:
        first_ts = min(t["entry_ts"] for t in trades)
        days_elapsed = (datetime.now(timezone.utc).timestamp() - first_ts) / 86400
    else:
        days_elapsed = 0.0

    failures = []
    if total_trades < min_trades:
        failures.append(f"trades {total_trades} < required {min_trades}")
    if days_elapsed < min_days:
        failures.append(f"days elapsed {days_elapsed:.1f} < required {min_days}")
    if win_rate < min_win_rate:
        failures.append(f"win rate {win_rate:.1%} < required {min_win_rate:.1%}")
    if expectancy_usd <= 0:
        failures.append(f"expectancy ${expectancy_usd:.4f} is not positive (after fees & slippage)")
    if max_drawdown_pct >= kill_threshold_pct:
        failures.append(f"max drawdown {max_drawdown_pct:.1%} >= kill threshold {kill_threshold_pct:.1%}")

    return ValidationResult(
        total_trades=total_trades,
        win_rate=win_rate,
        expectancy_usd=expectancy_usd,
        max_drawdown_pct=max_drawdown_pct,
        days_elapsed=days_elapsed,
        passed=not failures,
        failures=failures,
    )


def _print_report(r: ValidationResult) -> None:
    print("=" * 60)
    print("PAPER TRADING VALIDATION REPORT")
    print("=" * 60)
    print(f"Completed paper trades : {r.total_trades}")
    print(f"Win rate                : {r.win_rate:.1%}")
    print(f"Expectancy / trade      : ${r.expectancy_usd:.4f}  (net of fees & slippage)")
    print(f"Max drawdown observed   : {r.max_drawdown_pct:.1%}")
    print(f"Days since first trade  : {r.days_elapsed:.1f}")
    print("-" * 60)
    if r.passed:
        print("RESULT: PASS")
    else:
        print("RESULT: FAIL")
        for f in r.failures:
            print(f"  - {f}")
    print("=" * 60)
    if not r.passed:
        print(
            "\nThis is the gate for even considering Prompt 6's live-trading flags. "
            "A FAIL here means: keep paper trading, don't touch "
            "LIVE_TRADING_CONFIRMED_1/2/3 yet."
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate a paper-trading run against acceptance criteria.")
    parser.add_argument("--min-trades", type=int, default=DEFAULT_MIN_TRADES)
    parser.add_argument("--min-days", type=float, default=DEFAULT_MIN_DAYS)
    parser.add_argument("--min-win-rate", type=float, default=DEFAULT_MIN_WIN_RATE)
    args = parser.parse_args()

    result = asyncio.run(
        validate(
            min_trades=args.min_trades,
            min_days=args.min_days,
            min_win_rate=args.min_win_rate,
            kill_threshold_pct=settings.TOTAL_DRAWDOWN_KILL_PCT,
        )
    )
    _print_report(result)
    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    main()
